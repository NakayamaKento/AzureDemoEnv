'use strict';
/**
 * Azure Functions v4 HTTP トリガー — Bot Framework メッセージエンドポイント
 * POST /api/messages
 *
 * Bot Service → Teams → ここに届く → SRE Agent API → Teams にプロアクティブ返信
 */

const { app } = require('@azure/functions');
const {
  CloudAdapter,
  ConfigurationBotFrameworkAuthentication,
  TurnContext,
  MessageFactory
} = require('botbuilder');
const { TeamsBot } = require('../bot');

// ── Bot Framework 認証設定（UAMI ベース — クライアントシークレット不要）──
const botAuth = new ConfigurationBotFrameworkAuthentication({
  MicrosoftAppId:       process.env.MICROSOFT_APP_ID,
  MicrosoftAppType:     process.env.MICROSOFT_APP_TYPE,     // 'UserAssignedMSI'
  MicrosoftAppTenantId: process.env.MICROSOFT_APP_TENANT_ID
});

const adapter = new CloudAdapter(botAuth);

// ── エラーハンドラー ──────────────────────────────────────────────────────
adapter.onTurnError = async (turnContext, error) => {
  console.error('[onTurnError]', error.message, error.stack);
  await turnContext.sendActivity(
    MessageFactory.text(`⚠️ エラーが発生しました: ${error.message}`)
  );
};

// ── Bot インスタンス ─────────────────────────────────────────────────────
const bot = new TeamsBot(adapter);

// ── HTTP トリガー登録 ────────────────────────────────────────────────────
app.http('messages', {
  methods: ['POST'],
  authLevel: 'anonymous',
  // Functions host adds the /api prefix automatically.
  route: 'messages',
  handler: async (request) => {
    try {
      const bodyText = await request.text();
      const activity = JSON.parse(bodyText);
      const authHeader = request.headers.get('authorization') ?? '';

      let statusCode = 200;
      let responseBody = '';

      const fakeReq = {
        method: 'POST',
        headers: {
          authorization: authHeader
        },
        body: activity
      };

      const fakeRes = {
        socket: {},
        status(code) {
          statusCode = code;
          return this;
        },
        header() {
          return this;
        },
        send(body) {
          if (typeof body !== 'undefined' && body !== null) {
            responseBody = typeof body === 'string' ? body : JSON.stringify(body);
          }
          return this;
        },
        end() {
          return this;
        }
      };

      await adapter.process(fakeReq, fakeRes, async (turnContext) => {
        await bot.run(turnContext);
      });

      return {
        status: statusCode,
        body: responseBody
      };
    } catch (err) {
      console.error('[messages handler]', err?.stack || err);
      return { status: 500, body: err?.message || 'Unknown error' };
    }
  }
});

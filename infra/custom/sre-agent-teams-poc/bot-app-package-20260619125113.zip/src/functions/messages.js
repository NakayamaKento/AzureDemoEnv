'use strict';
/**
 * Azure Functions v4 HTTP トリガー — Bot Framework メッセージエンドポイント
 * POST /api/messages
 *
 * Bot Service → Teams → ここに届く → SRE Agent API → Teams にプロアクティブ返信
 */

const { app } = require('@azure/functions');
const {
  CloudAdapter,
  ConfigurationBotFrameworkAuthentication,
  TurnContext,
  MessageFactory
} = require('botbuilder');
const { TeamsBot } = require('../bot');

// ── Bot Framework 認証設定（UAMI ベース — クライアントシークレット不要）──
const botAuth = new ConfigurationBotFrameworkAuthentication({
  MicrosoftAppId:       process.env.MICROSOFT_APP_ID,
  MicrosoftAppType:     process.env.MICROSOFT_APP_TYPE,     // 'UserAssignedMSI'
  MicrosoftAppTenantId: process.env.MICROSOFT_APP_TENANT_ID
});

const adapter = new CloudAdapter(botAuth);

// ── エラーハンドラー ──────────────────────────────────────────────────────
adapter.onTurnError = async (turnContext, error) => {
  console.error('[onTurnError]', error.message, error.stack);
  await turnContext.sendActivity(
    MessageFactory.text(`⚠️ エラーが発生しました: ${error.message}`)
  );
};

// ── Bot インスタンス ─────────────────────────────────────────────────────
const bot = new TeamsBot(adapter);

// ── HTTP トリガー登録 ────────────────────────────────────────────────────
app.http('messages', {
  methods: ['POST'],
  authLevel: 'anonymous',
  // Functions host adds the /api prefix automatically.
  route: 'messages',
  handler: async (request) => {
    try {
      const bodyText = await request.text();
      const incoming = new Request('https://localhost/api/messages', {
        method: 'POST',
        headers: request.headers,
        body: bodyText
      });

      const invokeResponse = await adapter.process(incoming, async (turnContext) => {
        await bot.run(turnContext);
      });

      if (!invokeResponse) {
        return { status: 200 };
      }

      return {
        status: invokeResponse.status ?? 200,
        body: invokeResponse.body
      };
    } catch (err) {
      console.error('[messages handler]', err?.stack || err);
      return { status: 500, body: err?.message || 'Unknown error' };
    }
  }
});
